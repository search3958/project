#!/bin/bash
cd "$(dirname "$0")"

# Get current IP
MY_IP=$(ipconfig getifaddr en0)
echo "IP: $MY_IP"

# Update /etc/hosts
sudo sed -i '' '/sentaro/d' /etc/hosts
echo "$MY_IP sentaro.local" | sudo tee -a /etc/hosts > /dev/null
echo "$MY_IP sentaro" | sudo tee -a /etc/hosts > /dev/null

# Copy HTML to Apache
sudo cp index.html /Library/WebServer/Documents/index.html

# Restart Apache
sudo apachectl restart

# Update dnsmasq
sudo tee /opt/homebrew/etc/dnsmasq.conf > /dev/null << EOF
address=/sentaro.local/$MY_IP
address=/sentaro/$MY_IP
listen-address=0.0.0.0
bind-interfaces
port=53
no-resolv
no-poll
EOF
sudo brew services restart dnsmasq 2>/dev/null

echo ""
echo "=== 完了 ==="
echo "アクセスURL: http://$MY_IP"
echo "アクセスURL: http://sentaro.local"
echo "アクセスURL: http://sentaro"
