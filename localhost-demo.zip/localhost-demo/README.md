# イントラネット構築手順

## 概要
同一LAN内のサーバーPCにHTTPサーバーを立て、スマホなどの他のデバイスから `http://sentaro.local` でアクセスできるようにする手順。

**最終目標：** LAN内の全デバイスがブラウザで `http://sentaro.local` を開ける状態にする。

---

## 必要なもの

| ツール | 用途 | macOS | Windows |
|--------|------|-------|---------|
| HTTPサーバー | HTMLを配信 | Apache（標準搭載） | IIS（標準搭載）または XAMPP |
| DNSサーバー | ホスト名解決 | dnsmasq（Homebrew） | dnsmasq（Chocolatey）または Windows DNSサーバー |
| mDNS | `.local`ホスト名のネットワーク広報 | dns-sd（標準搭載） | Bonjour（Apple提供、別途インストール） |
| hostsファイル | ローカルのホスト名解決 | `/etc/hosts` | `C:\Windows\System32\drivers\etc\hosts` |

---

## 前提条件
- サーバーPCとスマホが同一LAN（同一Wi-Fi）に接続されている
- サーバーPCのIPアドレスが固定、もしくはDHCPで割り当てられたIPを把握している

---

## macOSでの構築手順

### ステップ1: サーバーPCのIPアドレスを確認
```bash
ipconfig getifaddr en0
```
例: `192.168.11.23` が返ってくる。このIPを以下で `SERVER_IP` と呼ぶ。

### ステップ2: hostsファイルにホスト名を追加
```bash
echo "${SERVER_IP} sentaro.local" | sudo tee -a /etc/hosts
echo "${SERVER_IP} sentaro" | sudo tee -a /etc/hosts
```
**解説：** `/etc/hosts` はローカルのDNS解決テーブル。これによりサーバーPC自身が `sentaro.local` → `192.168.11.23` と解決できるようになる。

### ステップ3: Apacheを起動
```bash
sudo apachectl start
```
Apacheがポート80でHTTPリクエストを待ち受ける状態になる。

### ステップ4: 配信用HTMLファイルを設置
```bash
sudo cp index.html /Library/WebServer/Documents/index.html
```
macOSのApacheのデフォルトルートは `/Library/WebServer/Documents/` 。

### ステップ5: dnsmasqをインストール・設定（DNSサーバー）
```bash
brew install dnsmasq
```

dnsmasqの設定ファイルを作成：
```bash
cat > /opt/homebrew/etc/dnsmasq.conf << EOF
address=/sentaro.local/${SERVER_IP}
address=/sentaro/${SERVER_IP}
listen-address=0.0.0.0
bind-interfaces
port=53
no-resolv
no-poll
EOF
```

dnsmasqを起動：
```bash
sudo brew services restart dnsmasq
```

**解説：** dnsmasqはDNSサーバーとして、`sentaro.local` や `sentaro` の問い合わせに `SERVER_IP` を返す。`listen-address=0.0.0.0` によりLAN内の全デバイスからのDNS查询に応答できる。

### ステップ6: mDNSでホスト名をネットワークに広報（最も重要）
```bash
dns-sd -P sentaro _http._tcp local. 80 sentaro.local ${SERVER_IP} &
```

**解説：** これが核心。`dns-sd -P` はBonjour/mDNSプロキシレコードを登録するコマンド。
- `sentaro` = サービスインスタンス名
- `_http._tcp` = サービスタイプ（HTTP）
- `local.` = ドメイン
- `80` = ポート番号
- `sentaro.local` = ホスト名
- `${SERVER_IP}` = IPアドレス

これにより、LAN内の全デバイス（スマホ含む）がmDNS経由で `sentaro.local` → `${SERVER_IP}` と解決できるようになる。

**注意：** このコマンドはバックグラウンドで常駐させる必要がある。サーバー再起動時に再実行が必要。

### ステップ7: ファイアウォールを解除
```bash
sudo /usr/libexec/ApplicationFirewall/socketfilterfw --setglobalstate off
```

**解説：** macOSのファイアウォールがポート80への外部接続をブロックする可能性があるため解除。本番環境ではファイアウォールのルールでポート80を許可する方が安全。

### ステップ8: DNSキャッシュクリア・mDNSResponder再起動
```bash
sudo dscacheutil -flushcache
sudo killall -HUP mDNSResponder
```

---

## Windowsでの構築手順（参考）

### IISを使用する場合
1. **IISを有効化：** コントロールプログラム → プログラムと機能 → Windowsの機能の有効化または無効化 → 「Internet Information Services」にチェック
2. **HTMLファイルを配置：** `C:\inetpub\wwwroot\index.html` に配置
3. **hostsファイルを編集：** `C:\Windows\System32\drivers\etc\hosts` に以下を追加（メモ帳を管理者として実行）
   ```
   192.168.11.23 sentaro.local
   192.168.11.23 sentaro
   ```
4. **ファイアウォールでポート80を許可：** Windows Defenderファイアウォール → 詳細設定 → 受信の規則 → 新規作成 → ポート80/TCPを許可

### DNSサーバー（dnsmasq）を Windows で動かす場合
1. [dnsmasq for Windows](http://thekelleys.org.uk/dnsmasq/doc.html) をダウンロード
2. 上記と同じ設定の `dnsmasq.conf` を作成
3. `dnsmasq.exe` を実行

### mDNS（Bonjour）を Windows で動かす場合
1. [Bonjour Print Services](https://support.apple.com/kb/DL999) をインストール（Apple提供、無料）
2. インストール後、Windowsで `.local` ホスト名がmDNSで解決可能になる

---

## ネットワークの仕組み（全体像）

```
スマホから http://sentaro.local にアクセスするときの流れ：

1. スマホがブラウザで "sentaro.local" を入力
2. スマホがmDNS（Bonjour）で "sentaro.local" を multicast询问
3. サーバーPCのdns-sdが "192.168.11.23" と応答
4. スマホが 192.168.11.23:80 にHTTP接続
5. サーバーPCのApacheが index.html を返す
6. スマホにWebページが表示される
```

**なぜ `/etc/hosts` だけでは動かないのか：**
`/etc/hosts` はローカルPCのみが参照するファイル。他のデバイスには影響しない。
mDNS（dns-sd）がLAN上にホスト名とIPの対応を multicast で broadcast することで、他のデバイスも解決できるようになる。

---

## 起動スクリプト（run.sh）

```bash
#!/bin/bash
cd "$(dirname "$0")"

# 現在のIPアドレスを取得
MY_IP=$(ipconfig getifaddr en0)
echo "サーバーIP: $MY_IP"

# /etc/hostsを更新
sudo sed -i '' '/sentaro/d' /etc/hosts
echo "$MY_IP sentaro.local" | sudo tee -a /etc/hosts > /dev/null
echo "$MY_IP sentaro" | sudo tee -a /etc/hosts > /dev/null

# ApacheにHTMLをコピーして再起動
sudo cp index.html /Library/WebServer/Documents/index.html
sudo apachectl restart

# dnsmasq設定を更新して再起動
sudo tee /opt/homebrew/etc/dnsmasq.conf > /dev/null << EOF
address=/sentaro.local/$MY_IP
address=/sentaro/$MY_IP
listen-address=0.0.0.0
bind-interfaces
port=53
no-resolv
no-poll
EOF
sudo brew services restart dnsmasq 2>/dev/null

# mDNSでホスト名を広報
dns-sd -P sentaro _http._tcp local. 80 sentaro.local $MY_IP &

echo ""
echo "完了。アクセスURL: http://sentaro.local"
```

---

## アクセスURL

| URL | どこからでも使えるか |
|-----|---------------------|
| `http://192.168.11.23` | すべてのデバイス（IP直指定） |
| `http://sentaro.local` | dns-sdが動いていればすべてのデバイス |
| `http://sentaro` | DHCP検索ドメイン設定時のみ |

---

## トラブルシューティング

### スマホからアクセスできない場合
1. **IPで接続できるか確認：** `http://192.168.11.23` で試す。ダメならファイアウォールの問題
2. **dns-sdが動いているか確認：** `ps aux | grep dns-sd` でプロセス確認
3. **mDNSが届いているか確認：** スマホのmDNSブラウザアプリ（例: "Discovery - DNS-SD Browser"）で `_http._tcp.local` を検索

### dns-sdが止まった場合
```bash
dns-sd -P sentaro _http._tcp local. 80 sentaro.local $(ipconfig getifaddr en0) &
```

### IPアドレスが変わった場合
`run.sh` を再実行すると自動で更新される。
手動の場合は `SERVER_IP` を含む設定をすべて差し替え。

---

## ファイアウォールに関する補足
- macOS: `socketfilterfw` で制御。本番ではルール追加が推奨
- Windows: Windows Defenderファイアウォールの受信規則でポート80を許可
- ルーターのファイアウォール: 通常はLAN内の通信は制限しないが、制限がある場合はルーター設定を確認
